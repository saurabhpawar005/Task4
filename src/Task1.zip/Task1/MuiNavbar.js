import { AppBar, Button, Toolbar, Typography } from '@mui/material'
import React from 'react'

function MuiNavbar() {
  

  return (
    <>
    <AppBar>
        <Toolbar sx={{backgroundColor:"pink"}}>
        <Typography variant='h5' sx={{color:"black"}}>Shopping Website</Typography>
      
        <Button 
        sx={{ marginLeft:"auto"}}variant="contained" >Buy Now</Button>
        </Toolbar>
    </AppBar>

    </>
  )
}

export default MuiNavbar