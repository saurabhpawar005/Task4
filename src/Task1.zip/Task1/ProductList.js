import React from 'react'
import { Button } from 'react-bootstrap'

function ProductList({ item }) {
// const onHandleAddBag = () =>{
// onAddBag ({name,price});
// };
  return (
    <>
      <div className='product-card' >

        <img src=" https://m.media-amazon.com/images/I/71yzJoE7WlL._SX679_.jpg" width={"200px"} height={"150px"} />

        <h5>iPhone 14 pro Max (256GB)</h5>

        <p><strong>Price</strong> :₹1,43,990</p>

        <p> <strong>Rating</strong>:5</p>
        <Button  variant="primary">Add Bag</Button>


      </div>

      <div className='product-card'>
        <img src='https://in-media.apjonlinecdn.com/catalog/product/cache/b3b166914d87ce343d4dc5ec5117b502/8/2/824H9PA-3_T1681788532.png' width={"200px"} height={"150px"} />
        <h5>HP ENVY x360 2-in-1 Laptop OLED Touch</h5>

        <h6><strong>Price</strong> :₹124,999</h6>
        <h6> <strong>Rating</strong>:5</h6>
        <Button variant="primary">Add Bag</Button>

      </div>
      <div className='product-card'>

        <img src='https://m.media-amazon.com/images/I/71J8tz0UeJL._SL1500_.jpg' width={"200px"} height={"150px"} />

        <h5>Samsung Galaxy S22 Ultra 5G (256GB)</h5>

        <h6><strong>Price</strong> :₹1,09,999</h6>
        <h6> <strong>Rating</strong>:5</h6>
        <Button variant="primary">Add Bag</Button>
      </div>
    </>


  )
}

export default ProductList



