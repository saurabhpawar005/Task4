import React from 'react';
import MuiNavbar from './MuiNavbar.js';
import ProductList from './ProductList.js';
import "./style.css";


function main() {

    
  return (
    <div className='product-container'>
      <MuiNavbar/>
      <ProductList/>
    </div>
  )
}

export default main;




<div>
<h1>Staff Leave Management</h1>
<form>
<label for="start-date">Start Date:</label>
<input type="date" id="start-date" name="start-date" required></input><br></br>

<label for="end-date">End Date:</label>
<input type="date" id="end-date" name="end-date" required></input><br></br>

<label for="reason">Reason:</label>
<textarea id="reason" name="reason" required></textarea><br></br>

<button type="button" onclick="submitLeaveRequest()">Submit</button>
</form>
</div>