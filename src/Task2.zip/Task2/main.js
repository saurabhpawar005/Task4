
import Second from './second';
import Third from './third';




function Main() {
    return (
        <>
        <Second/>
        {/* <Third/> */}
        </>
    )
}

export default Main;